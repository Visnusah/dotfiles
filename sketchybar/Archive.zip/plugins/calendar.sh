#!/bin/bash

sketchybar --set $NAME label="$(date +'%a %d %b %I:%M %p')"
